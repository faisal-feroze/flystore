 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dashboard-admin','data' => []]); ?>
<?php $component->withName('dashboard-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startSection('content'); ?>

    <div class="">
      <form id="" action="<?php echo e(route('product_save')); ?>" method="POST" enctype="multipart/form-data">
       <?php echo csrf_field(); ?>
       <p class="ph">Add Product</p>
       <hr>
       <div class="row joy">

         <div class="col">
            <label for="">Product Name</label>
            <input type="text" class="form-control" name="name">
         </div>

          <div class="col">
            <label for="">Product Category</label>
            <select id="" name="category_id" class="form-control">
              <option value=" " selected>- Select -</option>
              <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <div class="col">
             <label for="">Product Unit</label>
             <input type="text" class="form-control" name="unit">
          </div>
       </div>

       <div class="row joy">

         <div class="col">
            <label for="">Product Description</label>
            <textarea name="description" class="form-control" rows="8" cols="80"></textarea>
         </div>

       </div>


       <div class="row joy">
         <div class="col">
            <label for="">Regular Price</label>
            <input type="number" class="form-control" name="regular_price">
         </div>

         <div class="col">
            <label for="">Discount Price</label>
            <input type="number" class="form-control" name="discount_price">
         </div>

         <div class="col">
            <label for="">Stock</label>
            <input type="number" class="form-control" name="current_stock">
         </div>
       </div>


       <div class="row joy">
         <div class="col">
            <label for="">product Main Image</label>
            <input type="file" class="form-control" name="image">
         </div>

         <div class="col">
            <label for="">product Image 1</label>
            <input type="file" class="form-control" name="image1">
         </div>

         <div class="col">
            <label for="">product Image 2</label>
            <input type="file" class="form-control" name="image2">
         </div>

         <div class="col">
            <label for="">product Image 3</label>
            <input type="file" class="form-control" name="image3">
         </div>

       </div>


       <div class="row joy">
         <div class="col">
           <label for="">Publication Status</label>
           <select id="" name="publication_status" class="form-control">
             <option value=" " selected>- Select -</option>
             <option value="1">Yes</option>
             <option value="0">No</option>
           </select>
         </div>

         <div class="col">
         </div>

         <div class="col">
         </div>

         <div class="col">
         </div>

       </div>

       <button type="submit" class="btn btn-primary">Add Product</button>

      </form>

    </div>


    <?php $__env->stopSection(); ?>

 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH E:\flystore\flystore\resources\views/admin/add_products.blade.php ENDPATH**/ ?>