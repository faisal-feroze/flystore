 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dashboard-admin','data' => []]); ?>
<?php $component->withName('dashboard-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startSection('content'); ?>

    <p class="ph">All Category</p>
    <hr>

    <div class="add_category">

      <form  action="<?php echo e(route('add_category')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <div class="row joy">
          <div class="col">
             <label for="">Category Name</label>
             <input type="text" class="form-control" name="name">
          </div>

          <div class="col">
            <label for="">Publication Status</label>
            <select id="" name="publication_status" class="form-control">
              <option value=" " selected>- Select -</option>
              <option value="1">Yes</option>
              <option value="0">No</option>
            </select>
          </div>
        </div>

        <div class="row joy">

          <div class="col">
             <label for="">Category Description</label>
             <textarea name="description" class="form-control" rows="5" cols="80"></textarea>
          </div>

        </div>
        <button type="submit" class="btn btn-primary">Add Category</button>
      </form>

    </div>

    <div class="">

      <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Category</h6>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>SL</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Publication Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>

                  <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                      <form  action="<?php echo e(route('category_update',$data->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <td><?php echo e($count++); ?></td>
                        <td> <input type="text" class="form-control" name="name" value="<?php echo e($data->name); ?>"></td>
                        <td> <input type="text" class="form-control" name="description" value="<?php echo e($data->description); ?>"></td>
                        <td>
                          <select id="" name="publication_status" class="form-control">
                            <?php if($data->publication_status == 1): ?>
                               <option value="1" selected>Yes</option>
                            <?php else: ?>
                               <option value="0" selected>No</option>
                            <?php endif; ?>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                          </select>
                        </td>
                        <td> <input class="btn btn-primary" type="submit" name="" value="Update"></td>
                      </form>
                    </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>
            </div>
          </div>
        </div>



    </div>


    <?php $__env->stopSection(); ?>

 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH E:\flystore\flystore\resources\views/admin/show_category.blade.php ENDPATH**/ ?>